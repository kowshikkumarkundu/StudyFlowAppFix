# StudyFlow

Offline Android study planner and spaced-repetition tracker.

## Build

This project uses Android Gradle Plugin 8.3.2, Kotlin 1.9.23, Gradle 8.7, and JDK 17.

The GitHub Actions workflow at `.github/workflows/build-apk.yml` builds a debug APK on pushes to `main`/`master` and on manual workflow dispatch.

## Important implementation status

This source package is a starter implementation, not a fully verified production release. The timer's current session persistence and pause-aware midnight accounting require further engineering and testing. Monthly analytics, JSON import/export, theme preferences, and full editing flows are not implemented yet. Run the GitHub Actions build and tests before installing.
