# Keep Room database entities and generated adapters safe during shrinking.
-keep class androidx.room.** { *; }
