package com.studyflow.app.data

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [SubjectEntity::class, TopicEntity::class, RevisionEntity::class, StudySessionEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "studyflow.db")
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = INSTANCE ?: return@launch
                            listOf(SubjectEntity(name = "Bangla", colorHex = "#2E7D32"), SubjectEntity(name = "English", colorHex = "#1565C0"), SubjectEntity(name = "Mathematical Reasoning", colorHex = "#C62828"), SubjectEntity(name = "General Science", colorHex = "#6A1B9A"), SubjectEntity(name = "Bangladesh Affairs", colorHex = "#00695C"), SubjectEntity(name = "International Affairs", colorHex = "#D84315"), SubjectEntity(name = "ICT & Computer", colorHex = "#0277BD")).forEach { database.appDao().insertSubject(it) }
                        }
                    }
                }).fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}
