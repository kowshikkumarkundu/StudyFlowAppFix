package com.studyflow.app.domain

import android.content.Context
import android.os.SystemClock
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.studyflow.app.data.AppDao
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

val Context.timerPrefs by preferencesDataStore(name = "study_timer")
enum class TimerMode { MAIN_STUDY, REVISION }
data class ActiveTimerState(val isActive: Boolean = false, val isPaused: Boolean = false, val subjectId: Long = 0, val topicId: Long? = null, val revisionId: Long? = null, val subjectName: String = "", val topicTitle: String = "", val mode: TimerMode = TimerMode.MAIN_STUDY, val startWallTimestamp: Long = 0, val accumulatedSeconds: Long = 0, val currentDisplaySeconds: Long = 0)

class TimerManager(private val context: Context, private val dao: AppDao, private val scope: CoroutineScope) {
    private val _state = MutableStateFlow(ActiveTimerState())
    val state: StateFlow<ActiveTimerState> = _state.asStateFlow()
    private var tickJob: Job? = null
    private var lastResumeElapsed: Long = 0
    private var lastResumeWall: Long = 0
    init { scope.launch {
        val p = context.timerPrefs.data.first()
        if (p[booleanPreferencesKey("active")] == true) {
            val paused = p[booleanPreferencesKey("paused")] ?: false
            val startWall = p[longPreferencesKey("startWall")] ?: System.currentTimeMillis()
            val lastWall = p[longPreferencesKey("lastWall")] ?: startWall
            var accum = p[longPreferencesKey("accum")] ?: 0L
            if (!paused) accum += maxOf(0L, (System.currentTimeMillis() - lastWall) / 1000)
            lastResumeElapsed = SystemClock.elapsedRealtime(); lastResumeWall = System.currentTimeMillis()
            _state.value = ActiveTimerState(true, paused, p[longPreferencesKey("subId")] ?: 0L, p[longPreferencesKey("topId")]?.takeIf { it != -1L }, p[longPreferencesKey("revId")]?.takeIf { it != -1L }, p[stringPreferencesKey("subName")] ?: "", p[stringPreferencesKey("topTitle")] ?: "", TimerMode.valueOf(p[stringPreferencesKey("mode")] ?: TimerMode.MAIN_STUDY.name), startWall, accum, accum)
            if (!paused) startTicker()
        }
    } }
    @Synchronized fun startTimer(subjectId: Long, subjectName: String, topicId: Long?, topicTitle: String, mode: TimerMode, revisionId: Long? = null) {
        if (_state.value.isActive) return
        val now = System.currentTimeMillis(); lastResumeElapsed = SystemClock.elapsedRealtime(); lastResumeWall = now
        _state.value = ActiveTimerState(isActive = true, subjectId = subjectId, topicId = topicId, revisionId = revisionId, subjectName = subjectName, topicTitle = topicTitle, mode = mode, startWallTimestamp = now)
        persist(); startTicker()
    }
    fun pauseTimer() { val c = _state.value; if (!c.isActive || c.isPaused) return; val total = c.accumulatedSeconds + maxOf(0L, (SystemClock.elapsedRealtime() - lastResumeElapsed) / 1000); tickJob?.cancel(); _state.value = c.copy(isPaused = true, accumulatedSeconds = total, currentDisplaySeconds = total); persist() }
    fun resumeTimer() { val c = _state.value; if (!c.isActive || !c.isPaused) return; lastResumeElapsed = SystemClock.elapsedRealtime(); lastResumeWall = System.currentTimeMillis(); _state.value = c.copy(isPaused = false); persist(); startTicker() }
    suspend fun stopTimer(): Long {
        val c = _state.value; if (!c.isActive) return 0L
        tickJob?.cancel(); var total = c.accumulatedSeconds
        if (!c.isPaused) total += maxOf(0L, (SystemClock.elapsedRealtime() - lastResumeElapsed) / 1000)
        val endWall = System.currentTimeMillis()
        // Note: session wall-clock segmentation currently needs pause-aware segment tracking for exact statistics.
        if (total >= 10) dao.insertSessions(SessionMidnightSplitter.splitSession(c.subjectId, c.topicId, c.revisionId, c.mode.name, c.subjectName, c.topicTitle, c.startWallTimestamp, endWall))
        _state.value = ActiveTimerState(); context.timerPrefs.edit { it.clear() }; return total
    }
    private fun startTicker() { tickJob?.cancel(); tickJob = scope.launch(Dispatchers.Default) { while (isActive) { delay(1000); val c = _state.value; if (c.isActive && !c.isPaused) { val added = maxOf(0L, (SystemClock.elapsedRealtime() - lastResumeElapsed) / 1000); _state.value = c.copy(currentDisplaySeconds = c.accumulatedSeconds + added) } } } }
    private fun persist() { val c = _state.value; scope.launch(Dispatchers.IO) { context.timerPrefs.edit { p -> p[booleanPreferencesKey("active")] = c.isActive; p[booleanPreferencesKey("paused")] = c.isPaused; p[longPreferencesKey("subId")] = c.subjectId; p[longPreferencesKey("topId")] = c.topicId ?: -1L; p[longPreferencesKey("revId")] = c.revisionId ?: -1L; p[stringPreferencesKey("subName")] = c.subjectName; p[stringPreferencesKey("topTitle")] = c.topicTitle; p[stringPreferencesKey("mode")] = c.mode.name; p[longPreferencesKey("startWall")] = c.startWallTimestamp; p[longPreferencesKey("lastWall")] = lastResumeWall; p[longPreferencesKey("accum")] = c.accumulatedSeconds } } }
}
