package com.studyflow.app.domain

import com.studyflow.app.data.StudySessionEntity
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object SessionMidnightSplitter {
    fun splitSession(subjectId: Long, topicId: Long?, revisionId: Long?, sessionType: String, subjectName: String, topicTitle: String, startEpochMillis: Long, endEpochMillis: Long, zoneId: ZoneId = ZoneId.systemDefault()): List<StudySessionEntity> {
        require(endEpochMillis >= startEpochMillis) { "End time cannot be before start time" }
        val result = mutableListOf<StudySessionEntity>()
        var cursor = startEpochMillis
        while (cursor < endEpochMillis) {
            val date = Instant.ofEpochMilli(cursor).atZone(zoneId).toLocalDate()
            val nextMidnight = date.plusDays(1).atStartOfDay(zoneId).toInstant().toEpochMilli()
            val chunkEnd = minOf(endEpochMillis, nextMidnight)
            val seconds = (chunkEnd - cursor) / 1000
            if (seconds > 0) result += StudySessionEntity(
                subjectId = subjectId,
                topicId = topicId,
                revisionId = revisionId,
                sessionType = sessionType,
                subjectName = subjectName,
                topicTitle = topicTitle,
                date = date.format(DateTimeFormatter.ISO_LOCAL_DATE),
                startTimestamp = cursor,
                endTimestamp = chunkEnd,
                durationSeconds = seconds
            )
            cursor = chunkEnd
        }
        return result
    }
}
