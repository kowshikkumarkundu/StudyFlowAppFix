package com.studyflow.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "subjects", indices = [Index(value = ["name"], unique = true)])
data class SubjectEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val colorHex: String = "#1A73E8", val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "topics", foreignKeys = [ForeignKey(entity = SubjectEntity::class, parentColumns = ["id"], childColumns = ["subjectId"], onDelete = ForeignKey.CASCADE)], indices = [Index("subjectId")])
data class TopicEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val subjectId: Long, val title: String, val notes: String? = null, val targetDate: String, val isCompleted: Boolean = false, val completedAt: Long? = null, val initialStudyDate: String? = null, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "revisions", foreignKeys = [ForeignKey(entity = TopicEntity::class, parentColumns = ["id"], childColumns = ["topicId"], onDelete = ForeignKey.CASCADE), ForeignKey(entity = SubjectEntity::class, parentColumns = ["id"], childColumns = ["subjectId"], onDelete = ForeignKey.CASCADE)], indices = [Index("topicId"), Index("subjectId"), Index("scheduledDate")])
data class RevisionEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val topicId: Long?, val subjectId: Long, val topicTitle: String, val notes: String? = null, val scheduledDate: String, val intervalDay: Int = 0, val isAutomatic: Boolean = false, val isCompleted: Boolean = false, val completedAt: Long? = null, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "study_sessions", indices = [Index("date"), Index("sessionType")])
data class StudySessionEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val subjectId: Long, val topicId: Long?, val revisionId: Long?, val sessionType: String, val subjectName: String, val topicTitle: String, val date: String, val startTimestamp: Long, val endTimestamp: Long, val durationSeconds: Long)

data class TopicWithSubject(val id: Long, val subjectId: Long, val subjectName: String, val subjectColor: String, val title: String, val notes: String?, val targetDate: String, val isCompleted: Boolean, val completedAt: Long?, val initialStudyDate: String?)
data class RevisionWithSubject(val id: Long, val topicId: Long?, val subjectId: Long, val subjectName: String, val subjectColor: String, val topicTitle: String, val notes: String?, val scheduledDate: String, val intervalDay: Int, val isAutomatic: Boolean, val isCompleted: Boolean, val completedAt: Long?)
data class SubjectDurationSummary(val subjectId: Long, val subjectName: String, val sessionType: String, val totalSeconds: Long)

@Dao
interface AppDao {
    @Query("SELECT * FROM subjects ORDER BY name ASC") fun getAllSubjects(): Flow<List<SubjectEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertSubject(subject: SubjectEntity): Long
    @Query("""SELECT t.id, t.subjectId, s.name AS subjectName, s.colorHex AS subjectColor, t.title, t.notes, t.targetDate, t.isCompleted, t.completedAt, t.initialStudyDate FROM topics t INNER JOIN subjects s ON t.subjectId = s.id WHERE t.targetDate = :date ORDER BY t.isCompleted ASC, t.id DESC""") fun getTopicsForDate(date: String): Flow<List<TopicWithSubject>>
    @Query("SELECT * FROM topics WHERE id = :id LIMIT 1") suspend fun getTopicById(id: Long): TopicEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertTopic(topic: TopicEntity): Long
    @Delete suspend fun deleteTopic(topic: TopicEntity)
    @Query("UPDATE topics SET isCompleted = :completed, completedAt = :completedAt WHERE id = :id") suspend fun setTopicCompletion(id: Long, completed: Boolean, completedAt: Long?)
    @Query("UPDATE topics SET initialStudyDate = :initialDate WHERE id = :id AND initialStudyDate IS NULL") suspend fun setInitialStudyDateIfNull(id: Long, initialDate: String): Int
    @Query("""SELECT r.id, r.topicId, r.subjectId, s.name AS subjectName, s.colorHex AS subjectColor, r.topicTitle, r.notes, r.scheduledDate, r.intervalDay, r.isAutomatic, r.isCompleted, r.completedAt FROM revisions r INNER JOIN subjects s ON r.subjectId = s.id WHERE r.scheduledDate = :date AND r.isCompleted = 0 ORDER BY r.isAutomatic ASC, r.id ASC""") fun getDueRevisionsForDate(date: String): Flow<List<RevisionWithSubject>>
    @Query("""SELECT r.id, r.topicId, r.subjectId, s.name AS subjectName, s.colorHex AS subjectColor, r.topicTitle, r.notes, r.scheduledDate, r.intervalDay, r.isAutomatic, r.isCompleted, r.completedAt FROM revisions r INNER JOIN subjects s ON r.subjectId = s.id WHERE r.scheduledDate < :date AND r.isCompleted = 0 ORDER BY r.scheduledDate ASC""") fun getMissedRevisions(date: String): Flow<List<RevisionWithSubject>>
    @Query("SELECT * FROM revisions WHERE topicId = :topicId AND isAutomatic = 1") suspend fun getAutomaticRevisionsForTopic(topicId: Long): List<RevisionEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertRevision(revision: RevisionEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertRevisions(revisions: List<RevisionEntity>)
    @Query("UPDATE revisions SET isCompleted = 1, completedAt = :completedAt WHERE id = :id") suspend fun markRevisionCompleted(id: Long, completedAt: Long)
    @Insert suspend fun insertSessions(sessions: List<StudySessionEntity>)
    @Query("SELECT * FROM study_sessions ORDER BY startTimestamp DESC") fun getAllSessions(): Flow<List<StudySessionEntity>>
    @Query("SELECT subjectId, subjectName, sessionType, SUM(durationSeconds) as totalSeconds FROM study_sessions GROUP BY subjectId, sessionType ORDER BY subjectName ASC") fun getSubjectSummaries(): Flow<List<SubjectDurationSummary>>
    @Query("SELECT COALESCE(SUM(durationSeconds), 0) FROM study_sessions WHERE date = :date AND sessionType = :type") fun getTotalSecondsForDateAndType(date: String, type: String): Flow<Long>
    @Query("SELECT COUNT(*) FROM topics WHERE targetDate = :date AND isCompleted = 1") fun countCompletedTopicsForDate(date: String): Flow<Int>
}
