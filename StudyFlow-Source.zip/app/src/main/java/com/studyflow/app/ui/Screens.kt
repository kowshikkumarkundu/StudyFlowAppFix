package com.studyflow.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.studyflow.app.StudyFlowApp
import com.studyflow.app.data.*
import com.studyflow.app.domain.TimerMode
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

@Composable fun HomeScreen(app: StudyFlowApp) {
    val today = remember { LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE) }
    val subjects by app.database.appDao().getAllSubjects().collectAsState(initial = emptyList())
    val topics by app.database.appDao().getTopicsForDate(today).collectAsState(initial = emptyList())
    val due by app.database.appDao().getDueRevisionsForDate(today).collectAsState(initial = emptyList())
    val missed by app.database.appDao().getMissedRevisions(today).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope(); var addTopic by remember { mutableStateOf(false) }; var addManual by remember { mutableStateOf(false) }
    Scaffold(floatingActionButton = { Column { SmallFloatingActionButton(onClick = { addManual = true }) { Icon(Icons.Default.Alarm, "Manual revision") }; Spacer(Modifier.height(8.dp)); FloatingActionButton(onClick = { addTopic = true }) { Icon(Icons.Default.Add, "Add topic") } } }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)) {
            item { LiveClockHeader() }
            item { Text("Today's Main Study (${topics.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            if (topics.isEmpty()) item { Card(Modifier.fillMaxWidth()) { Text("No topics for today. Tap + to plan your study.", Modifier.padding(16.dp)) } }
            else items(topics, key = { it.id }) { t ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(t.isCompleted, onCheckedChange = { checked -> scope.launch { app.database.appDao().setTopicCompletion(t.id, checked, if (checked) System.currentTimeMillis() else null) } })
                    Column(Modifier.weight(1f)) { Text(t.subjectName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); Text(t.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold) }
                    IconButton(onClick = { scope.launch { app.revisionScheduler.scheduleAutomaticRevisionsIfFirstTime(t.id, t.subjectId, t.title); app.timerManager.startTimer(t.subjectId, t.subjectName, t.id, t.title, TimerMode.MAIN_STUDY) } }) { Icon(Icons.Default.PlayArrow, "Study") }
                    IconButton(onClick = { scope.launch { app.database.appDao().deleteTopic(TopicEntity(t.id, t.subjectId, t.title, t.notes, t.targetDate)) } }) { Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error) }
                } }
            }
            item { Text("Today's Due Revisions (${due.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            if (due.isEmpty()) item { Card(Modifier.fillMaxWidth()) { Text("All revisions cleared for today!", Modifier.padding(16.dp)) } }
            else items(due, key = { it.id }) { r -> RevisionCard(r, app, false) }
            if (missed.isNotEmpty()) { item { Text("Missed Revisions (${missed.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) }; items(missed, key = { it.id }) { r -> RevisionCard(r, app, true) } }
        }
    }
    if (addTopic) AddTopicDialog(subjects, today, app) { addTopic = false }
    if (addManual) ManualRevisionDialog(subjects, app) { addManual = false }
}

@Composable private fun RevisionCard(r: RevisionWithSubject, app: StudyFlowApp, missed: Boolean) {
    val days = if (missed) ChronoUnit.DAYS.between(LocalDate.parse(r.scheduledDate), LocalDate.now()) else 0
    Card(Modifier.fillMaxWidth(), colors = if (missed) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = .3f)) else CardDefaults.cardColors()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(if (missed) "${r.subjectName} • Overdue by $days days" else "${r.subjectName} • ${if (r.isAutomatic) "Day ${r.intervalDay}" else "Manual"}", style = MaterialTheme.typography.labelSmall); Text(r.topicTitle, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold) }
            Button(onClick = { app.timerManager.startTimer(r.subjectId, r.subjectName, r.topicId, r.topicTitle, TimerMode.REVISION, r.id) }) { Text("Revise") }
        }
    }
}

@Composable private fun AddTopicDialog(subjects: List<SubjectEntity>, today: String, app: StudyFlowApp, close: () -> Unit) {
    var subjectId by remember { mutableStateOf(subjects.firstOrNull()?.id ?: 0L) }; var title by remember { mutableStateOf("") }; val scope = rememberCoroutineScope()
    AlertDialog(onDismissRequest = close, title = { Text("Add Study Topic") }, text = { Column {
        subjects.forEach { s -> Row(Modifier.fillMaxWidth().clickable { subjectId = s.id }, verticalAlignment = Alignment.CenterVertically) { RadioButton(subjectId == s.id, onClick = { subjectId = s.id }); Text(s.name) } }
        OutlinedTextField(title, { title = it }, label = { Text("Chapter / Topic Name") }, modifier = Modifier.fillMaxWidth())
    } }, confirmButton = { Button(enabled = title.isNotBlank() && subjectId != 0L, onClick = { scope.launch { app.database.appDao().insertTopic(TopicEntity(subjectId = subjectId, title = title.trim(), targetDate = today)) }; close() }) { Text("Add") } }, dismissButton = { TextButton(onClick = close) { Text("Cancel") } })
}

@Composable private fun ManualRevisionDialog(subjects: List<SubjectEntity>, app: StudyFlowApp, close: () -> Unit) {
    var subjectId by remember { mutableStateOf(subjects.firstOrNull()?.id ?: 0L) }; var title by remember { mutableStateOf("") }; var date by remember { mutableStateOf(LocalDate.now().plusDays(1).toString()) }; val scope = rememberCoroutineScope()
    AlertDialog(onDismissRequest = close, title = { Text("Schedule Manual Revision") }, text = { Column {
        subjects.forEach { s -> Row(Modifier.fillMaxWidth().clickable { subjectId = s.id }, verticalAlignment = Alignment.CenterVertically) { RadioButton(subjectId == s.id, onClick = { subjectId = s.id }); Text(s.name) } }
        OutlinedTextField(title, { title = it }, label = { Text("Topic") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
    } }, confirmButton = { Button(enabled = title.isNotBlank() && subjectId != 0L && runCatching { LocalDate.parse(date); true }.getOrDefault(false), onClick = { scope.launch { app.database.appDao().insertRevision(RevisionEntity(topicId = null, subjectId = subjectId, topicTitle = title.trim(), scheduledDate = date)) }; close() }) { Text("Schedule") } }, dismissButton = { TextButton(onClick = close) { Text("Cancel") } })
}

@Composable fun StatisticsScreen(app: StudyFlowApp) {
    val today = remember { LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE) }
    val main by app.database.appDao().getTotalSecondsForDateAndType(today, "MAIN_STUDY").collectAsState(initial = 0L)
    val revision by app.database.appDao().getTotalSecondsForDateAndType(today, "REVISION").collectAsState(initial = 0L)
    val subjects by app.database.appDao().getSubjectSummaries().collectAsState(initial = emptyList())
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(bottom = 96.dp)) {
        item { Text("Study Statistics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Today's Output", fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("Main Study: ${main / 60} mins"); Text("Revision: ${revision / 60} mins"); Text("Total: ${(main + revision) / 60} mins", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) } } }
        item { Text("Subject Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(subjects) { s -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("${s.subjectName} (${s.sessionType})"); Text("${s.totalSeconds / 60}m", fontWeight = FontWeight.Bold) } } }
    }
}

@Composable fun SettingsScreen() { Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
    Text("Settings & Privacy", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Offline Guarantee", fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text("StudyFlow requires ZERO internet access. All your study data is stored on-device in SQLite.") } }
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Spaced Repetition Schedule", fontWeight = FontWeight.Bold); Text("Automatic intervals generated on first study:\n• Day 1 (+1 day)\n• Day 3 (+3 days)\n• Day 7 (+7 days)\n• Day 15 (+15 days)\n• Day 30 (+30 days)") } }
} }
