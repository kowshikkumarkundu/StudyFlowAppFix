package com.studyflow.app

import android.app.Application
import com.studyflow.app.data.AppDatabase
import com.studyflow.app.domain.RevisionScheduler
import com.studyflow.app.domain.TimerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class StudyFlowApp : Application() {
    val database by lazy { AppDatabase.getInstance(this) }
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val revisionScheduler by lazy { RevisionScheduler(database.appDao()) }
    val timerManager by lazy { TimerManager(this, database.appDao(), appScope) }
}
