package com.studyflow.app.ui

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.studyflow.app.data.AppDao
import com.studyflow.app.domain.TimerManager
import com.studyflow.app.domain.TimerMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable fun LiveClockHeader() {
    var time by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { time = LocalDateTime.now(); delay(1000) } }
    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(time.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH)), style = MaterialTheme.typography.titleSmall)
            Text(time.format(DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.ENGLISH)), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable fun BoxScope.PersistentTimerOverlay(timerManager: TimerManager, dao: AppDao) {
    val state by timerManager.state.collectAsState(); val scope = rememberCoroutineScope(); var confirm by remember { mutableStateOf(false) }
    AnimatedVisibility(state.isActive, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut(), modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp)) {
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.inverseSurface, contentColor = MaterialTheme.colorScheme.inverseOnSurface, shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${state.mode.name}: ${state.subjectName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.inversePrimary)
                    Text(state.topicTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                    val s = state.currentDisplaySeconds; Text(String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                }
                IconButton(onClick = { if (state.isPaused) timerManager.resumeTimer() else timerManager.pauseTimer() }) { Icon(if (state.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause, "Pause/Resume", tint = Color.White) }
                IconButton(onClick = { if (state.mode == TimerMode.REVISION && state.revisionId != null) confirm = true else scope.launch { timerManager.stopTimer() } }) { Icon(Icons.Default.Stop, "Stop", tint = MaterialTheme.colorScheme.errorContainer) }
            }
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("Complete Revision?") }, text = { Text("Mark this revision session as completed?") }, confirmButton = { Button(onClick = { val id = state.revisionId; confirm = false; scope.launch { if (id != null) dao.markRevisionCompleted(id, System.currentTimeMillis()); timerManager.stopTimer() } }) { Text("Yes, Mark Completed") } }, dismissButton = { TextButton(onClick = { confirm = false; scope.launch { timerManager.stopTimer() } }) { Text("Keep Pending") } })
}
