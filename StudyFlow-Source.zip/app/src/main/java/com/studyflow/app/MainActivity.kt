package com.studyflow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.studyflow.app.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as StudyFlowApp
        setContent {
            MaterialTheme {
                val nav = rememberNavController(); val entry by nav.currentBackStackEntryAsState(); val route = entry?.destination?.route
                Scaffold(bottomBar = { NavigationBar {
                    listOf("home" to Icons.Default.Home, "stats" to Icons.Default.BarChart, "settings" to Icons.Default.Settings).forEach { (r, icon) ->
                        NavigationBarItem(icon = { Icon(icon, r) }, label = { Text(r.replaceFirstChar { it.uppercase() }) }, selected = route == r, onClick = { nav.navigate(r) { popUpTo("home"); launchSingleTop = true } })
                    }
                } }) { padding -> Box(Modifier.fillMaxSize().padding(padding)) {
                    NavHost(navController = nav, startDestination = "home") { composable("home") { HomeScreen(app) }; composable("stats") { StatisticsScreen(app) }; composable("settings") { SettingsScreen() } }
                    PersistentTimerOverlay(app.timerManager, app.database.appDao())
                } }
            }
        }
    }
}
