package com.studyflow.app.domain

import com.studyflow.app.data.AppDao
import com.studyflow.app.data.RevisionEntity
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class RevisionScheduler(private val dao: AppDao) {
    companion object {
        val INTERVAL_DAYS = listOf(1, 3, 7, 15, 30)
        fun calculateScheduleDates(startDate: LocalDate): List<Pair<Int, LocalDate>> = INTERVAL_DAYS.map { it to startDate.plusDays(it.toLong()) }
    }
    suspend fun scheduleAutomaticRevisionsIfFirstTime(topicId: Long, subjectId: Long, topicTitle: String, studyDate: LocalDate = LocalDate.now()): Boolean {
        val topic = dao.getTopicById(topicId) ?: return false
        if (topic.initialStudyDate != null) return false
        val existing = dao.getAutomaticRevisionsForTopic(topicId)
        if (existing.isNotEmpty()) { dao.setInitialStudyDateIfNull(topicId, studyDate.format(DateTimeFormatter.ISO_LOCAL_DATE)); return false }
        dao.setInitialStudyDateIfNull(topicId, studyDate.format(DateTimeFormatter.ISO_LOCAL_DATE))
        dao.insertRevisions(calculateScheduleDates(studyDate).map { (interval, date) -> RevisionEntity(topicId = topicId, subjectId = subjectId, topicTitle = topicTitle, notes = "Auto: Day $interval Revision", scheduledDate = date.format(DateTimeFormatter.ISO_LOCAL_DATE), intervalDay = interval, isAutomatic = true) })
        return true
    }
}
