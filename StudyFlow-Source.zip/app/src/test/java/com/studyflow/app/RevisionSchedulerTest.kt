package com.studyflow.app

import com.studyflow.app.domain.RevisionScheduler
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class RevisionSchedulerTest {
    @Test fun testIntervalCalculation() {
        val schedule = RevisionScheduler.calculateScheduleDates(LocalDate.of(2026, 11, 3))
        assertEquals(5, schedule.size)
        assertEquals(LocalDate.of(2026, 11, 4), schedule[0].second)
        assertEquals(LocalDate.of(2026, 11, 6), schedule[1].second)
        assertEquals(LocalDate.of(2026, 11, 10), schedule[2].second)
        assertEquals(LocalDate.of(2026, 11, 18), schedule[3].second)
        assertEquals(LocalDate.of(2026, 12, 3), schedule[4].second)
    }
}
